﻿AZSMZ ESP32 Matrix 控制板 - 固件说明
====================================
文件名                          烧写地址    说明
----------------------------------------------------------
FastLED_Functions_merged.bin    0x0        预编译演示固件(ESP32 core 1.0.6 构建)
FastLED_Functions_2x_merged.bin 0x0        预编译演示固件(ESP32 core 2.0.17 构建)
FastLED_Functions_2x.bin        0x10000    仅应用分区镜像(2.0.17), 改代码后快速刷写用

烧录方法:
  esptool --chip esp32 --port COM3 --baud 921600 ^
   --before default_reset --after hard_reset ^
   write_flash -z 0x0 FastLED_Functions_2x_merged.bin

注意: 合并镜像(.merged.bin)务必烧 0x0; 应用镜像(.bin)务必烧 0x10000。
